# Psoriasis Detection - IS > 2024-09-07 6:16pm
https://universe.roboflow.com/thesis-zv0qn/psoriasis-detection-is

Provided by a Roboflow user
License: CC BY 4.0

